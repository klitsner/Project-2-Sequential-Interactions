# Study 4 — Throw (liberating)

A single-step behavioral study: a crumpled statement ball and a trash can in a simple low-poly room, with the debt total shown at the top. The user grabs the ball and throws it; misses add interest, a hit lets the can swallow the debt and release it as $0.00.

## Components

- **Room:** one-point-perspective wall and floor with seams in the wall colour (`drawRoom()` in `common.js`); low-poly window and couch (`drawFurniture()`).
- **Trash can:** `assets/can.svg`, drawn with a swell/wobble transform (`drawCanSwell()`, `drawCan()`).
- **Ball:** 8 rolling frames (`assets/ball_roll_01.svg` … `08.svg`), stepped by distance while rolling, rotated in flight (`drawRollBall()`, `drawTheBall()`). Floor shadow shrinks and fades with height.
- **Cues:** white chevrons from the ball toward the can while held.
- **Debt:** counter, floating interest labels, and digit particles (`drawDebt()`, `addInterest()`, `startConsume()`, `updateConsume()`).

## Actions, feedback, states

| State (`S.state`) | Trigger | What happens |
|---|---|---|
| `ready` | idle / hover | Ball breathes; on hover it rises slightly and the cursor becomes `grab`. |
| `held` | press on the ball | Cursor `grabbing`; ball shrinks ~20 %, darkens and trembles; follows the cursor and can be lifted (`screenToWorld()`); chevrons point at the can. |
| `fly` | release | Leaves from the cursor at the cursor's velocity, then for 0.55 s eases toward an ideal throw into the can (`idealFrom()`, `AIM`, `AIMZ`); high arc (`G`), trail, rising tone, room brightens. Can bounce off the can's side. |
| `rollback` | lands outside the can | Bounces, then rolls back to the start using the roll frames; if it was a real throw, `addInterest()` adds 3 %, floats "+$…" to the counter, shakes it and plays a sour tone. |
| `in` → phases `eat` → `hold` → `release` → `zero` | drops through the rim | Digits fly into the can, which swells and trembles; a calming whoosh and open chord release the digits outward; light facets rise; total fades in as $0.00. |

Tuning values at the top of `study.js`: `G`, `AIM`, `AIMZ`, `VZK`, `T_FLIGHT`, `EASE_FOR`.

## Connecting it to other studies

- All state lives in the global `S`; `resetStudy()` restores the starting state.
- **Starting state:** the crumpled ball near the bottom centre; debt $12,024.00.
- **Completion:** `S.phase === 'zero'`: the debt reads $0.00.
- No event is emitted on completion. To chain studies, check `S.phase === 'zero'` in `frame()` (or add a callback where that state is set) and hand off to the next study.

## Files

| File | What it holds |
|---|---|
| `index.html` | Page shell: canvas, study label, reset button, asset map (`ASSETS`), script order |
| `style.css` | Stage layout (fills the window; framed at 390 × 844 on wide screens) |
| `js/core.js` | Shared: canvas setup + `resize()`, `lerp` / `clamp` / `now`, Web Audio (`audio`, `tone`, `makeVoice`), `pos()`, reset button wiring |
| `js/common.js` | Shared: asset loading into `IMG`, noise sounds (`burst`, `rustle`, `thud`, `makeNoiseVoice`), `softRipple`, `isMouse`, `easeIO`, low-poly ball (`makeBall`, `drawBall`, `triShade`), room/can drawing (`drawRoom`, `drawCan`, `worldToScreen`) |
| `js/study.js` | This study's state, input handling, physics and drawing |

`core.js` and `common.js` are identical across all four statement studies, so a combined repo can keep one shared copy. Some helpers in `common.js` are unused by this study.

## Assets

- `assets/can.svg` — low-poly trash can.
- `assets/ball_roll_01.svg` … `ball_roll_08.svg` — the ball rolling toward the viewer, 45° per frame.

## Run it

No build step and no dependencies. Open `index.html` in a browser, or serve the folder (`npx serve .` / `python3 -m http.server`) — a local server is recommended because some browsers block SVG images loaded from `file://`. Works on GitHub Pages as-is.

Sound uses the Web Audio API and starts after the first click (browser autoplay rules). Mouse input only (`pointerType === 'mouse'` or `'pen'`).
