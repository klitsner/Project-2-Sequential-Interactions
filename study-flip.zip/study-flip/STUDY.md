# Study 2 — Flip (curious)

A single-step behavioral study: a blank sheet hangs on a plain background with faint ink showing through. Hovering an edge brings in a glove that grips it and tugs; dragging across turns the sheet over to reveal an overdue credit card statement.

## Components

- **Sheet faces:** front = `assets/statement_front.svg` ("PAYMENT OVERDUE", red "$12,024.00"); back = plain paper with the front mirrored at ~1 % opacity, built on load (`buildFaces()`).
- **3D turn:** the sheet is drawn as 120 strips rotated about the centre axis parallel to the gripped edge, with perspective, a slight flex and tilt shading (`sample()`, `drawCard()`).
- **Glove:** simple low-poly white glove drawn in code (`glove()`), fixed at the middle of the hovered edge (`edgePoint()`).
- **Chevron cue:** two stemless two-line chevrons sliding in the drag direction (`drawGripAndArrow()`).

## Actions, feedback, states

| State (`S.state`) | Trigger | What happens |
|---|---|---|
| `back` | idle | Blank side up, soft drop shadow. No cue. |
| `back` (hover edge) | cursor within 26 px of any edge (`nearestEdge()`) | Glove fades in on that edge and tugs (the edge lifts slightly on a rhythm); chevrons slide toward the opposite edge; system cursor hidden. |
| `back` (drag) | press on an edge, drag in the chevron direction | Turn angle `S.phi` follows drag distance; rising "questioning" notes play per 30° and an airy swish follows speed. |
| `turning` | release past halfway, or drag past 80 % (auto-completes, no second click) | Springs to π. |
| `front` | turn settles | Statement reads correctly; low falling two-note answer. |
| back to `back` | release before halfway | Swings back. |

Drag ending is handled on `pointerup`, `pointercancel`, `lostpointercapture` and window `pointerup` (`endDrag()`).

## Connecting it to other studies

- All state lives in the global `S`; `resetStudy()` restores the starting state.
- **Starting state:** blank side up, centred, nothing gripped.
- **Completion:** `S.state === 'front'`: statement face up.
- No event is emitted on completion. To chain studies, check `S.state === 'front'` in `frame()` (or add a callback where that state is set) and hand off to the next study.

## Files

| File | What it holds |
|---|---|
| `index.html` | Page shell: canvas, study label, reset button, asset map (`ASSETS`), script order |
| `style.css` | Stage layout (fills the window; framed at 390 × 844 on wide screens) |
| `js/core.js` | Shared: canvas setup + `resize()`, `lerp` / `clamp` / `now`, Web Audio (`audio`, `tone`, `makeVoice`), `pos()`, reset button wiring |
| `js/common.js` | Shared: asset loading into `IMG`, noise sounds (`burst`, `rustle`, `thud`, `makeNoiseVoice`), `softRipple`, `isMouse`, `easeIO`, low-poly ball (`makeBall`, `drawBall`, `triShade`), room/can drawing (`drawRoom`, `drawCan`, `worldToScreen`) |
| `js/study.js` | This study's state, input handling, physics and drawing |

`core.js` and `common.js` are identical across all four statement studies, so a combined repo can keep one shared copy. Some helpers in `common.js` are unused by this study.

## Assets

- `assets/statement_front.svg` — the statement front (also used to build the faint bleed-through on the back).

## Run it

No build step and no dependencies. Open `index.html` in a browser, or serve the folder (`npx serve .` / `python3 -m http.server`) — a local server is recommended because some browsers block SVG images loaded from `file://`. Works on GitHub Pages as-is.

Sound uses the Web Audio API and starts after the first click (browser autoplay rules). Mouse input only (`pointerType === 'mouse'` or `'pen'`).
