# Study 3 — Crumple (crushing)

A single-step behavioral study: an overdue statement on a plain background. Hovering brings in two open low-poly gloves; pressing and holding makes them close into fists and shake as the paper is crushed into a low-poly ball.

## Components

- **Statement:** `assets/statement_front_lowpoly.svg`, clipped to a 22-point outline that morphs from the rectangle (`RECT`) to the ball outline (`TARGET`).
- **Crush facets:** a fan of flat-shaded triangles fades in over the printed face as it crushes (`frame()` → facet loop, `triShade()`), then the low-poly ball takes over (`makeBall()`, `drawBall()` in `common.js`).
- **Gloves:** 5 frames, open → fist (`assets/glove_01.svg` … `glove_05.svg`), mirrored for the left hand; frame chosen from curl (`glove()`).

## Actions, feedback, states

| State (`S.state`) | Trigger | What happens |
|---|---|---|
| `flat` | idle | Statement only. |
| `flat` (hover) | cursor over the sheet | Two open gloves fade in just outside the left and right edges with a gentle bob; cursor hidden. |
| `crush` | press and hold | Gloves close onto the edges (`S.close`), then crush level `S.c` rises, slow at first and then faster (`rate = 0.16 + c·0.75`). Glove frames step toward a fist; gloves and paper shake harder (`S.shake`); low groan (`makeVoice`) and dense crunches (`burst`). |
| back to `flat` | release early | Keeps 85 % of the crush (`S.L`) and slowly creeps back to it; gloves pull back. Pressing again continues. |
| `ball` | crush reaches 1 (~2.5 s held) | Heavy thud, small settling bounce, gloves fade away. |

## Connecting it to other studies

- All state lives in the global `S`; `resetStudy()` restores the starting state.
- **Starting state:** the flat statement, centred.
- **Completion:** `S.state === 'ball'`: a low-poly paper ball in the centre.
- No event is emitted on completion. To chain studies, check `S.state === 'ball'` in `frame()` (or add a callback where that state is set) and hand off to the next study.

## Files

| File | What it holds |
|---|---|
| `index.html` | Page shell: canvas, study label, reset button, asset map (`ASSETS`), script order |
| `style.css` | Stage layout (fills the window; framed at 390 × 844 on wide screens) |
| `js/core.js` | Shared: canvas setup + `resize()`, `lerp` / `clamp` / `now`, Web Audio (`audio`, `tone`, `makeVoice`), `pos()`, reset button wiring |
| `js/common.js` | Shared: asset loading into `IMG`, noise sounds (`burst`, `rustle`, `thud`, `makeNoiseVoice`), `softRipple`, `isMouse`, `easeIO`, low-poly ball (`makeBall`, `drawBall`, `triShade`), room/can drawing (`drawRoom`, `drawCan`, `worldToScreen`) |
| `js/study.js` | This study's state, input handling, physics and drawing |

`core.js` and `common.js` are identical across all four statement studies, so a combined repo can keep one shared copy. Some helpers in `common.js` are unused by this study.

## Assets

- `assets/statement_front_lowpoly.svg` — faceted statement face.
- `assets/glove_01.svg` … `glove_05.svg` — glove frames, open → fist.

## Run it

No build step and no dependencies. Open `index.html` in a browser, or serve the folder (`npx serve .` / `python3 -m http.server`) — a local server is recommended because some browsers block SVG images loaded from `file://`. Works on GitHub Pages as-is.

Sound uses the Web Audio API and starts after the first click (browser autoplay rules). Mouse input only (`pointerType === 'mouse'` or `'pen'`).
