# Study 1 — Pick up (drafty)

A single-step behavioral study: a sheet of paper lies face down on a plain grid while a draft keeps lifting its edge. The user waits for the right moment, grabs it, and peels it off the floor.

## Components

- **Ground:** plain light-gray grid (`frame()` → draw section).
- **Sheet:** 230 × 300, face down, smooth (not low-poly). The lifted part is drawn as thin strips bent around a cylinder with shading and perspective (`drawSheet()`).
- **Printed underside:** red bars standing in for text, generated in code on an offscreen canvas (`buildUnder()`).
- **Draft:** a gust every 1.5 s from the bottom, with white wind streaks (`frame()` → "draft" block; `SIDES`, `PERIOD`).
- **Shadows:** a blurred shadow under lifted strips and a contact shadow under the flat part (`drawSheet()`).

## Actions, feedback, states

| State (`S.state`) | Trigger | What happens |
|---|---|---|
| `floor` (wind) | idle | Each gust curls the bottom edge back past vertical, revealing the red text, then settles. Wind noise follows the gust. |
| `floor` (hover) | cursor over the sheet | The wind stops controlling it; the bottom edge peels up, still face down, and holds with a slight breathing. Cursor: `grab`. A rustle plays. |
| `drag` | press on the sheet, drag up | Cursor: `grabbing`. Peel distance follows the drag (`S.dGrab`); the curl radius grows so it lifts rather than folds; a peel sound follows drag speed. |
| back to `floor` | release before 80 % | Settles back down with a soft pat. |
| `finishing` → `held` | release past 80 %, or fully peeled | The sheet unbends (`S.u` 0→1) and floats flat above the floor with a larger, softer shadow; a soft tone plays. |

Key values: `PW`, `PH` (sheet size), `K` (perspective), `HL` (float height), `PERIOD` (gust interval) at the top of `study.js`. Easing is frame-rate independent (`kk()` in `frame()`).

## Connecting it to other studies

- All state lives in the global `S`; `resetStudy()` restores the starting state.
- **Starting state:** the sheet lies face down in the middle; gusts lift the bottom edge.
- **Completion:** `S.state === 'held'`: the sheet floats flat, blank side up.
- No event is emitted on completion. To chain studies, check `S.state === 'held'` in `frame()` (or add a callback where that state is set) and hand off to the next study.

## Files

| File | What it holds |
|---|---|
| `index.html` | Page shell: canvas, study label, reset button, asset map (`ASSETS`), script order |
| `style.css` | Stage layout (fills the window; framed at 390 × 844 on wide screens) |
| `js/core.js` | Shared: canvas setup + `resize()`, `lerp` / `clamp` / `now`, Web Audio (`audio`, `tone`, `makeVoice`), `pos()`, reset button wiring |
| `js/common.js` | Shared: asset loading into `IMG`, noise sounds (`burst`, `rustle`, `thud`, `makeNoiseVoice`), `softRipple`, `isMouse`, `easeIO`, low-poly ball (`makeBall`, `drawBall`, `triShade`), room/can drawing (`drawRoom`, `drawCan`, `worldToScreen`) |
| `js/study.js` | This study's state, input handling, physics and drawing |

`core.js` and `common.js` are identical across all four statement studies, so a combined repo can keep one shared copy. Some helpers in `common.js` are unused by this study.

## Assets

None as files: the sheet, underside text and grid are drawn in code. The study was designed from a "drafty" sheet SVG in the class process.

## Run it

No build step and no dependencies. Open `index.html` in a browser, or serve the folder (`npx serve .` / `python3 -m http.server`) — a local server is recommended because some browsers block SVG images loaded from `file://`. Works on GitHub Pages as-is.

Sound uses the Web Audio API and starts after the first click (browser autoplay rules). Mouse input only (`pointerType === 'mouse'` or `'pen'`).
